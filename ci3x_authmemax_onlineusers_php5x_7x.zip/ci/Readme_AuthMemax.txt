
* Authme Authentication Library
* @author Gilbert Pellegrom
* @link http://dev7studios.com
* @version 1.0


Online Users class
@package CodeIgniter
@subpackage Libraries
@category Add-Ons
@author MoShair
@link http://php-max.com/ci


1. Add the ci folder content to your CI directory (overwrite).

2. Give folder "captcha" 744 permission

3. Edit application/config/datebase.php and modify values.

4. Edit application/config/config.php and modify values don't forget to change the 
$config['encryption_key']

5. Edit application/config/authme.php and change these values 

$config['authme_name'] = 'YOUR_DOMAIN';
$config['authme_email'] = 'YOUR_DOMAIN_EMAIL';
$config['onlineusers_timeout'] = 1800;
$config['onlineusers_timeoffset'] = '+0';

