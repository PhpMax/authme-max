<?php
/*
* Authme Authentication Library
* @author Gilbert Pellegrom
* @link http://dev7studios.com
* @version 1.0
*/
class Authme_model extends CI_Model {
  public $users_table;
  public function __construct() {
    parent :: __construct();
    $this->load->database();
    $this->config->load('authme');
    $this->users_table = $this->config->item('authme_users_table');
    if (!$this->db->table_exists($this->users_table))
      $this->create_users_table();
  }
  public function get_user($user_id) {
    $query = $this->db->get_where($this->users_table, array('id' => $user_id));
    if ($query->num_rows())
      return $query->row();
    return false;
  }
  public function get_user_by_email($email) {
    $query = $this->db->get_where($this->users_table, array('email' => $email));
    if ($query->num_rows())
      return $query->row();
    return false;
  }
  public function get_users($order_by = 'id', $order = 'asc', $limit = 0, $offset = 0) {
    $this->db->order_by($order_by, $order);
    if ($limit)
      $this->db->limit($limit, $offset);
    $query = $this->db->get($this->users_table);
    return $query->result();
  }
  public function get_user_count() {
    return $this->db->count_all($this->users_table);
  }
  public function create_user($email, $password, $username, $acode, $gender, $country) {
    $ip = $this->input->ip_address();
    $data = array('username' => $username, 'email' => filter_var($email, FILTER_SANITIZE_EMAIL), 'password' => $password,
// Should be hashed
    'created' => time(), 'acode' => $acode, 'ip' => $ip, 'gender' => $gender, 'country' => $country);
    $this->db->insert($this->users_table, $data);
    return $this->db->insert_id();
  }
  public function update_user($user_id, $data) {
    $this->db->where('id', $user_id);
    $this->db->update($this->users_table, $data);
  }
  public function delete_user($user_id) {
    $this->db->delete($this->users_table, array('id' => $user_id));
  }
  public function update_user2($email, $data) {
    $this->db->where('email', $email);
    $this->db->update($this->users_table, $data);
  }
  public function delete_online_guest($user_id) {
    $this->db->where('user_ip =', $_SERVER['REMOTE_ADDR']);
    $this->db->where('user_id =', 0);
    if ($user_id) {
      $this->db->or_where('user_id =', $user_id);
    }
    $this->db->delete('online');
  }
  public function delete_online_member($user_id) {
    $this->db->where('user_id =', $user_id);
    $this->db->delete('online');
  }
  private function create_users_table() {
    print '<!DOCTYPE html>
<html>
<head>
<title>Install</title>
<link rel="stylesheet" href="' . base_url() . 'assests/style.css">
</head>
<body><h1>AuthmeMax Installation</h1>';
    $sql = "CREATE TABLE IF NOT EXISTS `online` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) CHARACTER SET utf8 NOT NULL,
  `path` text,
  `logged` int(20) NOT NULL,
  `user_id` int(9) NOT NULL,
  `user_ip` varchar(30) NOT NULL,
  `last_move` int(20) NOT NULL,
  `is_bot` int(1) NOT NULL,
  `agent` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
    $this->db->query($sql);
    echo '<p class="success">"online" table created successfully</p>';
    $sql = "CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(200) CHARACTER SET utf8 NOT NULL,
  `password` varchar(200) CHARACTER SET utf8 NOT NULL,
  `created` int(20) NOT NULL,
  `last_login` int(20) NOT NULL,
  `username` varchar(200) CHARACTER SET utf8 NOT NULL,
  `ip` varchar(20) CHARACTER SET utf8 NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `gender` tinyint(1) NOT NULL DEFAULT '1',
  `birthdate` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `acode` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `country` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `sec_question` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `sec_answer` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `website` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `last_mail` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;";
    $this->db->query($sql);
    echo '<p class="success">"users" table created successfully</p>';
    die('<p class="error">Please reload this page.</p></body></html>');
  }
}
/* End of file: authme_model.php */
/* Location: application/models/authme_model.php */