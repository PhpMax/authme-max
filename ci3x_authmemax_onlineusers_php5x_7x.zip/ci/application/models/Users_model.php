<?php
/*
* AuthMeMax Users Library
*
* @package Authentication
* @category Libraries
* @author Moh Shair
* @link http://php-max.com/ci
* @version 1.0
*
*/
if (!defined('BASEPATH'))
  exit ('No direct script access allowed');
class Users_model extends CI_Model {
  function get_all_search_posts_num($keyword) {
    $this->db->like('username', $keyword);
    return $this->db->count_all_results('users');
  }
  function get_all_search_posts($page, $keyword) {
    $this->db->order_by('id', 'desc');
    $this->db->like('username', $keyword);
    $this->db->limit(10, $page);
    $query = $this->db->get('users');
    return $query->result();
  }
  function get_all_posts_num() {
    return $this->db->count_all_results('users');
  }
  function get_all_posts($page) {
    $this->db->order_by('id', 'desc');
    $this->db->limit(10, $page);
    $query = $this->db->get('users');
    return $query->result();
  }
  function add_new_user($arr) {
    $this->db->insert('users', $arr);
  }
  function update_user($id, $arr) {
    $this->db->where('id', $id);
    $this->db->limit(1);
    $this->db->update('users', $arr);
  }
  function get_post($id) {
    $this->db->where('id', $id);
    $query = $this->db->get('users');
    if ($query->num_rows() !== 0) {
      return $query->result();
    }
    else
      return FALSE;
  }
  function check_username($username) {
    $this->db->where('name', $username);
    return $this->db->count_all_results('users');
  }
  function check_email($email) {
    $this->db->where('email', $email);
    return $this->db->count_all_results('users');
  }
}
/* End of file users_model.php */
/* Location: ./application/models/users_model.php */