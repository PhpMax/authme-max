<?php

//$config['enable_query_strings'] = FALSE;
$config['per_page'] = 10;
$config['display_pages'] = TRUE;
$config['use_page_numbers'] = FALSE;
$config['num_links'] = 3;

$config['full_tag_open'] = '<div class="art-pager">';
$config['full_tag_close'] = '</div>';
$config['first_link'] = 'First';
$config['first_tag_open'] = '';
$config['first_tag_close'] = '';
$config['last_link'] = 'Last';
$config['last_tag_open'] = '';
$config['last_tag_close'] = '';
$config['next_link'] = '&gt;';
$config['next_tag_open'] = '';
$config['next_tag_close'] = '';
$config['prev_link'] = '&lt;';
$config['prev_tag_open'] = '';
$config['prev_tag_close'] = '';
$config['cur_tag_open'] = '<a class="active" href="#">';
$config['cur_tag_close'] = '</a>';
$config['num_tag_open'] = '';
$config['num_tag_close'] = '';
$config['anchor_class'] = '';

?>
