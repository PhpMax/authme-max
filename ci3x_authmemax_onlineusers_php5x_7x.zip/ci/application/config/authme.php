<?php
/**
 * Authme-max Authentication Library
 *
 * @package Authentication
 * @category Libraries
 * @author Gilbert Pellegrom
 * @link http://php-max.com/ci
 * @link http://dev7studios.com
 * @version 1.0
 */

$config['authme_users_table'] = 'users';
$config['authme_password_min_length'] = 4;
$config['authme_portable_hashes'] = false;
$config['authme_name'] = 'YOUR_DOMAIN';
$config['authme_email'] = 'YOUR_DOMAIN_EMAIL';
$config['onlineusers_timeout'] = 1800;
$config['onlineusers_timeoffset'] = '+0';

/* End of file: authme.php */
/* Location: application/config/authme.php */