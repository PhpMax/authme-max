<?php
/*
* Authme Authentication Library
* @author Gilbert Pellegrom
* @link http://dev7studios.com
* @version 1.0
*/
if (!defined('BASEPATH'))
  exit ('No direct script access allowed');
class Authme {
  private $CI;
  protected $PasswordHash;
  public function __construct() {
    if (!file_exists($path = dirname(__FILE__) . '/../vendor/PasswordHash.php')) {
      show_error('The phpass class file was not found.');
    }
    $this->CI = & get_instance();
    $this->CI->load->database();
    $this->CI->load->library('session');
    $this->CI->load->model('authme_model');
    $this->CI->config->load('authme');
    include ($path);
    $this->PasswordHash = new PasswordHash(8, $this->CI->config->item('authme_portable_hashes'));
  }
  public function logged_in() {
    return $this->CI->session->userdata('logged_in');
  }
  public function login($email, $password) {
    $user = $this->CI->authme_model->get_user_by_email($email);
    if ($user) {
      if ($this->PasswordHash->CheckPassword($password, $user->password)) {
        $this->CI->authme_model->delete_online_guest($user->id);
        unset ($user->password);
        unset ($user->acode);
        unset ($user->created);
        unset ($user->last_login);
        unset ($user->country);
        unset ($user->last_mail);
        $this->CI->session->set_userdata(array('logged_in' => true, 'user' => $user));
        $this->CI->authme_model->update_user($user->id, array('last_login' => time()));
        return true;
      }
    }
    return false;
  }
  public function logout($redirect = false) {
    $user = $this->CI->session->userdata('user');
    $user_id = user('id');
    $this->CI->authme_model->delete_online_member($user_id);
    $this->CI->session->sess_destroy();
    if ($redirect) {
      $this->CI->load->helper('url');
      redirect($redirect, 'refresh');
    }
  }
  public function signup($email, $password, $username, $acode, $gender, $country) {
    $user = $this->CI->authme_model->get_user_by_email($email);
    if ($user)
      return false;
    $password = $this->PasswordHash->HashPassword($password);
    $this->CI->authme_model->create_user($email, $password, $username, $acode, $gender, $country);
    $this->CI->authme_model->delete_online_guest(0);
    return true;
  }
  public function reset_password($user_id, $new_password) {
    $new_password = $this->PasswordHash->HashPassword($new_password);
    $this->CI->authme_model->update_user($user_id, array('password' => $new_password));
  }
  public function change_email($user_id, $email, $acode) {
    $this->CI->authme_model->update_user($user_id, array('email' => $email, 'acode' => $acode));
    $this->logout();
  }
}
/* End of file: authme.php */
/* Location: application/libraries/authme.php */