
<div class="block" style="clear:both">
<div class="block-head">
Online
</div>
<div class="block-text">
<?php $this->load->view('online');?>
</div>
</div>



<div class="block" style="clear:both">
<div class="block-head">
Sidebar block1
</div>
<div class="block-text">
Text
</div>
</div>

<div class="block" style="clear:both">
<div class="block-head">
Download
</div>
<div class="block-text">
<a href="http://www.php-max.com/ci3x_authmemax_onlineusers_php5x_7x.zip">ci3x_authmemax_onlineusers_php5x_7x.zip</a> 70KB 
</div>
</div>