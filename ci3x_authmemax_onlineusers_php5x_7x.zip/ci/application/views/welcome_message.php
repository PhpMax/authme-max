<?php $this->load->view('head'); ?>

</head>
<body class="dhe-body">
<?php $this->load->view('header_bar'); ?>

Home

<h2><?php echo $title;?></h2>


<?php
if (logged_in()) {
  ?>

<p class="success">This content is only for members.</p>


<?php
if ($admin) {
  ?>

<p class="success">This content is only for Admin (user no = 1)</p>

<?php } ?>


<?php }else{
?>
<p class="success">You can see this line because you are not signed in yet.</p>
<?php } ?>


</div>

<div id="sidebar">
<?php $this->load->view('side_bar');?>
</div>

<div class="clearer">&nbsp;</div>

</div>

</div>
</div>


<?php $this->load->view('footer'); ?>


</body>
</html>