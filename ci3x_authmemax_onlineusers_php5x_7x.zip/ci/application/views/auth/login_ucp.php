<?php $this->load->view('head'); ?>

</head>
<body class="dhe-body">

<?php $this->load->view('header_bar'); ?>

<a href="<?php echo base_url();?>" class="">Home</a>
 » 
<?php echo $title;?>
 
<h2><?php echo $title;?></h2>


<?php 
    if($error) echo '<p class="error">'. $error .'</p>';
    echo form_open(); 
    echo form_label('Password:', 'password') .'<br />';
    echo form_password(array('name' => 'password', 'class'=>'inptxt_', 'size'=>30, 'maxlength'=>40, 'value' => set_value('password'))) .'<br />';
    echo form_error('password');
    echo form_submit(array('type' => 'submit', 'value' => 'Submit'));
    echo form_close();
    ?>





</div>

<div id="sidebar">
<?php $this->load->view('side_bar');?>
</div>

<div class="clearer">&nbsp;</div>

</div>

</div>
</div>


<?php $this->load->view('footer'); ?>

</body>
</html>