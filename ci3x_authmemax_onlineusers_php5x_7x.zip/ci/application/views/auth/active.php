<?php $this->load->view('head'); ?>

</head>
<body class="dhe-body">
<?php $this->load->view('header_bar'); ?>

<a href="<?php echo base_url();?>">Home</a>
 » 
<?php echo $title;?>
 
<h2><?php echo $title;?></h2>


<?php
if($msg)
{ 
echo '<div style="margin:50px">'.$msg.'.</div>';
}
?>




</div>

<div id="sidebar">
<?php $this->load->view('side_bar');?>
</div>

<div class="clearer">&nbsp;</div>

</div>

</div>
</div>


<?php $this->load->view('footer'); ?>

</body>
</html>