<?php $this->load->view('head'); ?>

</head>
<body class="dhe-body">
<?php $this->load->view('header_bar'); ?>

<a href="<?php echo base_url();?>">Home</a>
 » 
<?php echo $title;?>
 
<h2><?php echo $title;?></h2>




<?php 
    if($error) echo '<p class="error">'. $error .'</p>';
    echo form_open(); 

    echo form_label('<b>*Username:</b>', 'username') .'<br />';
    echo form_input(array('name' => 'username', 'class'=>'inptxt_', 'size'=>30, 'maxlength'=>20, 'value' => set_value('username'))) .'<br />';
    echo form_error('username');

    echo form_label('<b>*Email:</b>', 'email') .'<br />';
    echo form_input(array('name' => 'email', 'class'=>'inptxt_', 'size'=>30, 'maxlength'=>50, 'value' => set_value('email'))) .'<br />';
    echo form_error('email');

    echo form_label('<b>*Password:</b>', 'password') .'<br />';
    echo form_password(array('name' => 'password', 'class'=>'inptxt_', 'size'=>30, 'maxlength'=>20,  'value' => set_value('password'))) .'<br />';
    echo form_error('password');
    echo form_label('<b>*Password confirm:</b>', 'password_conf') .'<br />';
    echo form_password(array('name' => 'password_conf', 'class'=>'inptxt_', 'size'=>30, 'maxlength'=>20, 'value' => set_value('password_conf'))) .'<br />';
    echo form_error('password_conf');

    echo form_label('Country:', 'country') .'<br />';
    echo form_input(array('name' => 'country', 'class'=>'inptxt_', 'size'=>20, 'maxlength'=>20, 'value' => set_value('country'))) .'<br />';
    echo form_error('country');
?>

Gender: 
<br/>
<select name="gender" class="selectm">
<option value="1">Male</option>
<option value="2">Female</option>
</select> 
<br />

<?php
    echo form_label('<b>Captcha:</b>', 'captcha') .'<br />'.$image.'<br /> Please type in the 6 letters shown:';
    echo form_input(array('name' => 'captcha', 'class'=>'inptxt_', 'size'=>6, 'maxlength'=>6, 'value' => set_value('captcha'))) .'<br />';
    echo form_error('captcha');
    echo form_submit(array('type' => 'submit', 'value' => 'Submit'))
?>

</form>
<br/>

<div class="td0">
* Required fields
</div>





</div>

<div id="sidebar">
<?php $this->load->view('side_bar');?>
</div>

<div class="clearer">&nbsp;</div>

</div>

</div>
</div>


<?php $this->load->view('footer'); ?>

</body>
</html>