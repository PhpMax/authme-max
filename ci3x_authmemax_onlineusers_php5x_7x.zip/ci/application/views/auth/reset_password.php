<?php $this->load->view('head'); ?>

</head>
<body class="dhe-body">
<?php $this->load->view('header_bar'); ?>

<a href="<?php echo base_url();?>">Home</a>
 » 
<?php echo $title;?>
 
<h2><?php echo $title;?></h2>


	<?php 
	if($success){
		echo '<p class="success">You have successfully reset your password.</p>';
	} else {
	    echo form_open(); 
	    echo form_label('<b>Password:</b>', 'password') .'<br />';
	    echo form_password(array('name' => 'password', 'value' => set_value('password'))) .'<br />';
	    echo form_error('password');
	    echo form_label('<b>Confirm Password: </b>', 'password_conf') .'<br />';
	    echo form_password(array('name' => 'password_conf', 'value' => set_value('password_conf'))) .'<br />';
	    echo form_error('password_conf');
	    echo form_submit(array('type' => 'submit', 'value' => 'Save New Password'));
	    echo form_close();
    }
    ?>




</div>

<div id="sidebar">
<?php $this->load->view('side_bar');?>
</div>

<div class="clearer">&nbsp;</div>

</div>

</div>
</div>


<?php $this->load->view('footer'); ?>

</body>
</html>