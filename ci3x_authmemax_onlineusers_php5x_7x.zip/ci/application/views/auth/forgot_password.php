<?php $this->load->view('head'); ?>

</head>
<body class="dhe-body">
<?php $this->load->view('header_bar'); ?>

<a href="<?php echo base_url();?>">Home</a>
 » 
<?php echo $title;?>
 
<h2><?php echo $title;?></h2>


	<?php 
	if($success){
		echo '<p class="success">Thank you. We have sent you an email with further instructions on how to reset your password.</p>';
	} else {
	    echo form_open(); 
	    echo form_label('Email Address', 'email') .'<br />';
	    echo form_input(array('name' => 'email', 'class'=>'inptxt_', 'size'=>40, 'maxlength'=>100, 'value' => set_value('email'))) .'<br />';
	    echo form_error('email');
	    echo form_submit(array('type' => 'submit', 'value' => 'Reset Password'));
	    echo form_close();
    }
    ?>




</div>

<div id="sidebar">
<?php $this->load->view('side_bar');?>
</div>

<div class="clearer">&nbsp;</div>

</div>

</div>
</div>


<?php $this->load->view('footer'); ?>

</body>
</html>