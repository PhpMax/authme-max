<?php $this->load->view('head'); ?>

</head>
<body class="dhe-body">
<?php $this->load->view('header_bar'); ?>

<a href="<?php echo base_url();?>">Home</a>
 » 
<?php echo $title;?>
 
<h2><?php echo $title;?></h2>



<table class="ng-table responsive">
<tr>
<th>No.</th>
<th>Name</th>
<th>Country</th>
<th>Date</th>
</tr>

<?php if ($query): foreach ($query as $users): ?>

<tr>
<td>
<?php echo $users->id; ?>
</td>

<td>
<a href="<?php echo base_url() . 'users/' . $users->id; ?>">
<?php echo $users->username; ?>
</a>
</td>

<td>
<?php if($users->country){
echo $users->country;
}else
{
echo 'NA';
}
 ?>
</td>

<td>
<?php echo date('j.n.Y', $users->created); ?>
</td>

 </tr>

<?php endforeach;
 else: ?>
<tr><td colspan="4">No Data!</td></tr>
<?php endif; ?>
</table>

<?php echo $pager; ?>












</div>

<div id="sidebar">
<?php $this->load->view('side_bar');?>
</div>

<div class="clearer">&nbsp;</div>

</div>

</div>
</div>


<?php $this->load->view('footer'); ?>

</body>
</html>