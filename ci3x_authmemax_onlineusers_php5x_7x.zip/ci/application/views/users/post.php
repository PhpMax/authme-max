﻿<?php $this->load->view('head'); ?>

</head>
<body class="dhe-body">

<?php $this->load->view('header_bar'); ?>

<a href="<?php echo base_url();?>">Home</a>
 » 
<a href="<?php echo base_url();?>users">Members</a>
 » 
<?php echo $title;?>
 
<h2><?php echo $title;?></h2>

    <?php if ($found == 1) { ?>
        <?php if ($flashdata) {
            echo '<div class="error">' . $flashdata . '</div>';
        } ?>



        <table class="ng-table responsive">
            <?php
            if ($admin) {
                echo '<tr><td><b>IP: </b></td><td>' . $ip . '</td></tr>';
                echo '<tr><td><b>Email: </b></td><td>' . $email . '</td></tr>';
                echo '<tr><td><b>acode: </b></td><td>' . $acode . '</td></tr>';
            }
            ?>

            <tr><td>
                    <b>Username:</b> 
                </td><td>
    <?php echo $username; ?>
                </td></tr>
            <tr><td>
                    <b>No:</b> 
                </td><td>
    <?php echo $id; ?> 
                </td></tr>

            <tr><td>
                    <b>Gender:</b> 
                </td><td>
                    <?php
                    if ($gender == 1) {
                        echo 'Male';
                    } elseif ($gender == 2) {
                        echo 'Female';
                    } else {
                        echo 'Na';
                    }
                    ?>
                </td></tr>

            <tr><td>
                    <b>Country:</b> 
                </td><td>
    <?php echo $country; ?> 
                </td></tr>

            <tr><td>
                    <b>Website:</b> 
                </td><td>
                    <a href="<?php echo $website; ?>" target="_blank" rel="nofollow"><?php echo $website; ?></a> ^
                </td></tr>

            <tr><td>
                    <b>Birthday:</b> 
                </td><td>
    <?php echo $birthdate; ?> 
                </td></tr>

            <tr><td>
                    <b>Reg. Date:</b> 
                </td><td>
    <?php echo date('j.n.Y H:i:s', $created); ?> gmt
                </td></tr>

            <tr><td>
                    <b>Last login:</b> 
                </td><td>
    <?php echo date('j.n.Y H:i:s', $last_login); ?>  gmt
                </td></tr>
      

        </table>
        <br /><br />
    <?php
} else {
    echo '<div class="error" style="text-align:center;margin:100px">The member you are looking for does not exists.</div>';
}
?>





</div>

<div id="sidebar">
<?php $this->load->view('side_bar');?>
</div>

<div class="clearer">&nbsp;</div>

</div>

</div>
</div>


<?php $this->load->view('footer'); ?>

</body>
</html>