<?php $this->load->view('head'); ?>

</head>
<body class="dhe-body">

<?php $this->load->view('header_bar'); ?>

<a href="<?php echo base_url();?>">Home</a>
 » 
<a href="<?php echo base_url();?>users">Members</a>
 » 
<?php echo $title;?>
 
<h2><?php echo $title;?></h2>


    <?php
    if (logged_in()) {
    echo form_open('users/edit'); 
        ?>
            <input type="hidden" name="id" value="<?php echo $id; ?>" />
            <table border="0" cellbadding="2" cellspacing="2" class="td0">

                <tr>
                    <td>
                        <b>Email:</b>
                       </td>
                    <td>
                        <input type="text" name="email" readonly="readonly" size="50" maxlength="50" value="<?php echo $email; ?>" class="inptxt_" />
                    </td>
                </tr>

                <tr>
                    <td><b>Birthday::</b></td>
                    <td>
                        <select name="bday" class="selectm">
                            <option value="0" <?php if ($bday == 0) {
        echo 'selected="selected"';
    } ?>>0</option>
                            <option value="1" <?php if ($bday == 1) {
        echo 'selected="selected"';
    } ?>>1</option>
                            <option value="1" <?php if ($bday == 1) {
        echo 'selected="selected"';
    } ?>>1</option>
                            <option value="2" <?php if ($bday == 2) {
        echo 'selected="selected"';
    } ?>>2</option>
                            <option value="3" <?php if ($bday == 3) {
        echo 'selected="selected"';
    } ?>>3</option>
                            <option value="4" <?php if ($bday == 4) {
        echo 'selected="selected"';
    } ?>>4</option>
                            <option value="5" <?php if ($bday == 5) {
        echo 'selected="selected"';
    } ?>>5</option>
                            <option value="6" <?php if ($bday == 6) {
        echo 'selected="selected"';
    } ?>>6</option>
                            <option value="7" <?php if ($bday == 7) {
        echo 'selected="selected"';
    } ?>>7</option>
                            <option value="8" <?php if ($bday == 8) {
        echo 'selected="selected"';
    } ?>>8</option>
                            <option value="9" <?php if ($bday == 9) {
        echo 'selected="selected"';
    } ?>>9</option>
                            <option value="10" <?php if ($bday == 10) {
        echo 'selected="selected"';
    } ?>>10</option>
                            <option value="11" <?php if ($bday == 11) {
        echo 'selected="selected"';
    } ?>>11</option>
                            <option value="12" <?php if ($bday == 12) {
        echo 'selected="selected"';
    } ?>>12</option>
                            <option value="13" <?php if ($bday == 13) {
        echo 'selected="selected"';
    } ?>>13</option>
                            <option value="14" <?php if ($bday == 14) {
        echo 'selected="selected"';
    } ?>>14</option>
                            <option value="15" <?php if ($bday == 15) {
        echo 'selected="selected"';
    } ?>>15</option>
                            <option value="16" <?php if ($bday == 16) {
        echo 'selected="selected"';
    } ?>>16</option>
                            <option value="17" <?php if ($bday == 17) {
        echo 'selected="selected"';
    } ?>>17</option>
                            <option value="18" <?php if ($bday == 18) {
        echo 'selected="selected"';
    } ?>>18</option>
                            <option value="19" <?php if ($bday == 19) {
        echo 'selected="selected"';
    } ?>>19</option>
                            <option value="20" <?php if ($bday == 20) {
        echo 'selected="selected"';
    } ?>>20</option>
                            <option value="21" <?php if ($bday == 21) {
        echo 'selected="selected"';
    } ?>>21</option>
                            <option value="22" <?php if ($bday == 22) {
        echo 'selected="selected"';
    } ?>>22</option>
                            <option value="23" <?php if ($bday == 23) {
        echo 'selected="selected"';
    } ?>>23</option>
                            <option value="24" <?php if ($bday == 24) {
        echo 'selected="selected"';
    } ?>>24</option>
                            <option value="25" <?php if ($bday == 25) {
        echo 'selected="selected"';
    } ?>>25</option>
                            <option value="26" <?php if ($bday == 26) {
        echo 'selected="selected"';
    } ?>>26</option>
                            <option value="27" <?php if ($bday == 27) {
        echo 'selected="selected"';
    } ?>>27</option>
                            <option value="28" <?php if ($bday == 28) {
        echo 'selected="selected"';
    } ?>>28</option>
                            <option value="29" <?php if ($bday == 29) {
        echo 'selected="selected"';
    } ?>>29</option>
                            <option value="30" <?php if ($bday == 30) {
        echo 'selected="selected"';
    } ?>>30</option>
                            <option value="31" <?php if ($bday == 31) {
        echo 'selected="selected"';
    } ?>>31</option>
                        </select> 

                        <select name="bmonth" class="selectm">
                            <option value="0" <?php if ($bmonth == 0) {
        echo 'selected="selected"';
    } ?>>0</option>
                            <option value="1" <?php if ($bmonth == 1) {
        echo 'selected="selected"';
    } ?>>1</option>
                            <option value="2" <?php if ($bmonth == 2) {
        echo 'selected="selected"';
    } ?>>2</option>
                            <option value="3" <?php if ($bmonth == 3) {
        echo 'selected="selected"';
    } ?>>3</option>
                            <option value="4" <?php if ($bmonth == 4) {
        echo 'selected="selected"';
    } ?>>4</option>
                            <option value="5" <?php if ($bmonth == 5) {
        echo 'selected="selected"';
    } ?>>5</option>
                            <option value="6" <?php if ($bmonth == 6) {
        echo 'selected="selected"';
    } ?>>6</option>
                            <option value="7" <?php if ($bmonth == 7) {
        echo 'selected="selected"';
    } ?>>7</option>
                            <option value="8" <?php if ($bmonth == 8) {
        echo 'selected="selected"';
    } ?>>8</option>
                            <option value="9" <?php if ($bmonth == 9) {
        echo 'selected="selected"';
    } ?>>9</option>
                            <option value="10" <?php if ($bmonth == 10) {
        echo 'selected="selected"';
    } ?>>10</option>
                            <option value="11" <?php if ($bmonth == 11) {
        echo 'selected="selected"';
    } ?>>11</option>
                            <option value="12" <?php if ($bmonth == 12) {
        echo 'selected="selected"';
    } ?>>12</option>
                        </select> 
                        <input type="text" name="byear" size="5" maxlength="4" value="<?php echo $byear; ?>" class="inptxt_" style="width:50px;" />
                    </td>
                </tr>

                <tr>
                    <td>
                        <b>Gender: </b>
                    </td>
                    <td>
                        <select name="gender" class="selectm">
                            <option value="1" <?php if ($gender == '1') {
        echo 'selected="selected"';
    } ?>>Male</option>
                            <option value="2" <?php if ($gender == '2') {
        echo 'selected="selected"';
    } ?>>Female</option>
                        </select> 
                    </td>
                </tr>

                <tr>
                    <td><b>Country: </b></td>
                    <td>
                        <input type="text" name="country" size="19" maxlength="20" value="<?php echo $country; ?>" class="inptxt_" />
                    </td>
                </tr>

                <tr>
                    <td><b>Website :</b> <br />(For example your facebook page.): </td>
                    <td>
                        <input type="text" name="website" size="50" maxlength="100" value="<?php echo $website; ?>" class="inptxt_" />
                    </td>
                </tr>

                <tr>
                    <td>
                        <b>New Password: </b>
                        <br />Leave it blank to not change.
                    </td>
                    <td>
                        <input type="text" name="password" size="19" maxlength="20" value="" class="inptxt_" />
                    </td>
                </tr>

               

                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" value="Update" />
                    </td>
                </tr>
            </table>
        </form>

    <?php
} else {
    echo '<div class="error">Please login to view this page!</div>';
}
?>





</div>

<div id="sidebar">
<?php $this->load->view('side_bar');?>
</div>

<div class="clearer">&nbsp;</div>

</div>

</div>
</div>


<?php $this->load->view('footer'); ?>

</body>
</html>