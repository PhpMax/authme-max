<?php
$myid = user('id');
if(logged_in()){
$myname = user('username');
}
else
{
$myname = $this->session->userdata('username');
}
?>

<div id="center-wrapper">
<div class="dhe-article-info">

<h1 class="dhe-h1"><a href="<?php echo base_url();?>">php-max.com/ci</a></h1>
<p class="dhe-p dhe-large">Authme + Onlineusers for CodeIgniter</p>
<div id="dhe-step-navigation">
<div class="dhe-left">

<?php
if (logged_in()) {
$user = $this->session->userdata('user');
?>
Hello <a href="<?php echo base_url();?>users/<?php echo user('id');?>"><b><?php echo user('username');?></b></a> !
 | <a href="<?php echo base_url();?>logout">Logout</a>
 | <a href="<?php echo site_url("ucp");?>">Control Panel</a>
<?php
}
else {
?>
<a href="<?php echo site_url('login');?>">Login</a> |
<a href="<?php echo site_url('register');?>">Sign up</a>
<?php
  }
  ?>
 | <a href="<?php echo site_url('users');?>">Members</a>

 | Time: <?php echo date("H:i:s j.n.Y",time());?>

</div>	

<div class="dhe-clearer">&nbsp;</div>

</div>
</div>	






<div class="dhe-example-section" id="ex-1-2">
<div class="dhe-example-section-content">
<div class="use-sidebar sidebar-at-right">
<div id="content">



