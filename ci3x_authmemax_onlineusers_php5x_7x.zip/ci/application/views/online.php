<?php
if ($this->load->is_loaded('onlineusers')) {
  $total_visit = $this->onlineusers->total_visit();
  if ($total_visit > 0) {
    $total_guests = 0;
    $total_mems = 0;
    $total_bots = 0;
    $link = '';
    $usersArr = $this->onlineusers->get_info();
    foreach ($usersArr as $guest) {
      if ($guest->username && $guest->user_id) {
        $total_mems = $total_mems + 1;
      }
      if ($guest->is_bot) {
        $total_bots = $total_bots + 1;
        $guest->username = '<span style="color:#DD6F00">' . $guest->username . '</span>';
      }
      if (!$guest->is_bot && !$guest->user_id) {
        $total_guests = $total_guests + 1;
      }
      if ($guest->user_id) {
        $link = $link . '<a href=" ' . base_url() . 'users/' . $guest->user_id . '" rel="nofollow" title="'.date("j.n.Y H:i:s",$guest->logged).'">' . $guest->username . '</a> ';
      }
      else {
        $link = $link . $guest->username . ', ';
      }
    }
    ?>
    <?php
    echo '<p>Members (' . $total_mems . ') , Guests (' . $total_guests . ') , Bots (' . $total_bots . ')</p>';
    echo $link;
  }
}
?>