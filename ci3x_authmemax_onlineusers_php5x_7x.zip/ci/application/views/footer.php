<div class="footer">

<p class="footer-copyright">
Copyright © your.domain 2017 
<br />
memory_usage: {memory_usage} / elapsed_time: {elapsed_time} seconds. 
<br>
<?php echo (ENVIRONMENT === 'development') ? 'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?>
 - Php: <?php echo phpversion();?>
</p>

</div>
</div>
<div style="clear:both"></div>
<br/>









