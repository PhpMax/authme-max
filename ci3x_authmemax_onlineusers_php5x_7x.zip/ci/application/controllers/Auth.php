<?php
/*
* Authme Authentication Library
* @author Gilbert Pellegrom
* @link http://dev7studios.com
* @version 1.0
*/
if (!defined('BASEPATH'))
  exit ('No direct script access allowed');
class Auth extends CI_Controller {
  public function __construct() {
    parent :: __construct();
    $this->load->library('authme');
    $this->config->load('authme');
  }
  public function index() {
    if (!logged_in())
      redirect('auth/login');
// Redirect to your logged in landing page here
    redirect('');
  }
  public function login_ucp() {
    $data['title'] = $data['desc'] = "Control panel";
    $this->load->model('users_model');
    if (!logged_in())
      redirect('');
    $this->load->library('form_validation');
    $this->load->helper('form');
    $data['error'] = false;
    $email = user('email');
    $this->form_validation->set_rules('password', 'Password', 'required');
    if ($this->form_validation->run()) {
      if ($this->authme->login($email, set_value('password'))) {
        $id = user('id');
        foreach ($this->users_model->get_post($id) as $row) {
          $id = $data['id'] = $row->id;
          $email = $data['email'] = $row->email;
          $country = $data['country'] = $row->country;
          $birthdate = $row->birthdate;
          $gender = $data['gender'] = $row->gender;
          $website = $data['website'] = $row->website;
          if ($birthdate) {
            $birthdateArr = explode('.', $birthdate);
            $data['bday'] = $birthdateArr[0];
            $data['bmonth'] = $birthdateArr[1];
            $data['byear'] = $birthdateArr[2];
          }
          else {
            $data['bday'] = 0;
            $data['bmonth'] = 0;
            $data['byear'] = 0;
          }
        }
        $this->load->view('users/edit', $data);
      }
      else {
        $data['error'] = 'Error: Please check the password';
        $this->load->view('auth/login_ucp', $data);
      }
    }
    else {
      $this->load->view('auth/login_ucp', $data);
    }
  }
/**
* Login page
*/
  public function login() {
    if (isset ($_SERVER['HTTP_REFERER']) && !$this->session->userdata('ref')) {
      $ref = $_SERVER['HTTP_REFERER'];
      $this->session->set_userdata('ref', $ref);
    }
    else {
      $ref = $this->session->userdata('ref');
    }
// Redirect to your logged in landing page here
    if (logged_in())
      redirect('');
    $this->load->library('form_validation');
    $this->load->helper('form');
    $data['error'] = false;
    $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
    $this->form_validation->set_rules('password', 'Password', 'required');
    if ($this->form_validation->run()) {
      if ($this->authme->login(set_value('email'), set_value('password'))) {
// Redirect to your logged in landing page here
        redirect($ref);
      }
      else {
        $data['error'] = 'Invalid login, please check your password or email is correct.';
      }
    }
    $data['title'] = $data['desc'] = 'Login';
    $this->load->view('auth/login', $data);
  }
/**
* Signup page
*/
  public function signup() {
    $this->load->helper('captcha');
    $this->session->userdata('captcha');
    if (!$this->session->userdata('captcha')) {
      $length = 6;
      $characters = '23456789abcdefghjkmnprstuvwxyz';
      $charactersLength = strlen($characters);
      $word = '';
      for ($i = 0; $i < $length; $i++) {
        $word .= $characters[rand(0, $charactersLength - 1)];
      }
//      $word = rand(111111, 999999);
      $this->session->set_userdata('captcha', $word);
    }
    else {
      $word = $this->session->userdata('captcha');
    }
    $vals = array('word' => $word, 'img_path' => './captcha/', 'img_url' => base_url() . 'captcha/', 'font_path' => './assests/texb.ttf', 'img_width' => '150', 'img_height' => 30, 'expiration' => 1, 'word_length' => 8, 'font_size' => 16, 'img_id' => 'Imageid', 'pool' => '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
// White background and border, black text and red grid
    'colors' => array('background' => array(255, 255, 255), 'border' => array(128, 128, 128), 'text' => array(168, 0, 0), 'grid' => array(255, 40, 40)));
    $cap = create_captcha($vals);
    $data['image'] = $cap['image'];
// Redirect to your logged in landing page here
    if (logged_in())
      redirect('');
    $this->load->library('form_validation');
    $this->load->helper('form');
    $data['error'] = '';
    $username = set_value('username');
    $this->form_validation->set_rules('username', 'Username', 'min_length[3]|max_length[20]|required|is_unique[' . $this->config->item('authme_users_table') . '.username]');
    $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[' . $this->config->item('authme_users_table') . '.email]');
    $this->form_validation->set_rules('password', 'Password', 'min_length[3]|max_length[20]|required|min_length[' . $this->config->item('authme_password_min_length') . ']');
    $this->form_validation->set_rules('password_conf', 'Confirm password', 'required|matches[password]');
    $this->form_validation->set_rules('captcha', 'Captcha code', 'required');
    $this->form_validation->set_rules('gender', 'gender', 'integer');
    $this->form_validation->set_rules('country', 'country', 'max_length[50]');
    $this->form_validation->set_rules('captcha', 'Captcha', 'min_length[6]|required');
    if ($this->form_validation->run()) {
      if ($this->session->userdata('captcha') == $this->input->post('captcha')) {
        $length = 10;
        $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
        $charactersLength = strlen($characters);
        $acode = '';
        for ($i = 0; $i < $length; $i++) {
          $acode .= $characters[rand(0, $charactersLength - 1)];
        }
        if ($this->authme->signup(set_value('email'), set_value('password'), strip_tags(set_value('username')), $acode, set_value('gender'), strip_tags(set_value('country')))) {
          $this->authme->login(set_value('email'), set_value('password'));
// Do some post signup stuff like send a welcome email...
// Redirect to your logged in landing page here
          $email = set_value('email');
          $link = site_url('auth/activate/' . $email . '/' . $acode);
          $subject = $this->config->item('authme_name') . ' - Activate';
          $this->load->library('email');
          $this->email->from($this->config->item('authme_email'), $this->config->item('authme_name'));
// Change these details
          $this->email->to($email);
          $this->email->subject($subject);
          $this->email->message('Hello,

Please click on this link to verify your account.
' . $link);
          $this->email->send();
          redirect('');
        }
        else {
          $data['error'] = 'Failed';
        }
      }
      else {
        $data['error'] = 'Captcha is incorrect.';
      }
    }
    $data['title'] = 'Sign up';
    $data['desc'] = 'Register';
    $this->load->view('auth/signup', $data);
  }
/**
* Logout page
*/
  public function logout() {
    if (!logged_in())
      redirect('auth/login');
// Redirect to your logged out landing page here
    $this->authme->logout('/');
  }
/**
* Example dashboard page
*/
  public function dash() {
    if (!logged_in())
      redirect('auth/login');
    echo 'Hi, ' . user('username') . '. You have successfully  logged in. <a href="' . site_url('auth/logout') . '">Logout</a>';
  }
/**
* Forgot password page
*/
  public function forgot() {
// Redirect to your logged in landing page here
    if (logged_in())
      redirect('');
    $this->load->library('form_validation');
    $this->load->helper('form');
    $data['success'] = false;
    $this->form_validation->set_rules('email', 'Email', 'required|valid_email|callback_email_exists');
    if ($this->form_validation->run()) {
      $email = $this->input->post('email');
      $this->load->model('Authme_model');
      $user = $this->Authme_model->get_user_by_email($email);
      $last_mail = $user->last_mail;
      if (time() < $last_mail + 60 * 60 * 3) {
        die('Please check you mail: Inbox, Junk, Spam');
      }
      $slug = md5($user->id . $user->email . date('Ymd'));
      $link = site_url('auth/reset/' . $user->id . '/' . $slug);
      $subject = $this->config->item('authme_name') . ' - Password Reset';
      $this->load->library('email');
      $this->email->from($this->config->item('authme_email'), $this->config->item('authme_name'));
// Change these details
      $this->email->to($email);
      $this->email->subject($subject);
      $this->email->message('To reset your password please click the link below and follow the instructions:

' . $link . '

If you did not request to reset your password then please just ignore this email and no changes will occur.

Note: This reset code will expire after ' . date('j M Y') . '.');
      $send = $this->email->send();
      if ($send) {
        $data = array('last_mail' => time());
        $this->Authme_model->update_user2($email, $data);
      }
      $data['success'] = true;
    }
    $data['title'] = 'Forgot Password';
    $data['desc'] = 'Forgot Password';
    $this->load->view('auth/forgot_password', $data);
  }
/**
* CI Form Validation callback that checks a given email exists in the db
*
* @param string $email the submitted email
* @return boolean returns false on error
*/
  public function email_exists($email) {
    $this->load->model('Authme_model');
    if ($this->Authme_model->get_user_by_email($email)) {
      return true;
    }
    else {
      $this->form_validation->set_message('email_exists', '<span class="error">We couldn\'t find that email address in our system.</span>');
      return false;
    }
  }
/**
* Reset password page
*/
  public function reset() {
// Redirect to your logged in landing page here
    if (logged_in())
      redirect('');
    $this->load->library('form_validation');
    $this->load->helper('form');
    $data['success'] = false;
    $user_id = $this->uri->segment(3);
    if (!$user_id)
      show_error('Invalid reset code.');
    $hash = $this->uri->segment(4);
    if (!$hash)
      show_error('Invalid reset code.');
    $this->load->model('Authme_model');
    $user = $this->Authme_model->get_user($user_id);
    if (!$user)
      show_error('Invalid reset code.');
    $slug = md5($user->id . $user->email . date('Ymd'));
    if ($hash != $slug)
      show_error('Invalid reset code.');
    $this->form_validation->set_rules('password', 'Password:', 'required|min_length[' . $this->config->item('authme_password_min_length') . ']');
    $this->form_validation->set_rules('password_conf', 'Confirm password:', 'required|matches[password]');
    if ($this->form_validation->run()) {
      $this->authme->reset_password($user->id, $this->input->post('password'));
      $data['success'] = true;
    }
    $data['title'] = 'Forgot password';
    $data['desc'] = 'Get new password';
    $this->load->view('auth/reset_password', $data);
  }
  public function activate() {
    $data['msg'] = '';
    $email = $this->uri->segment(3);
    $acode = $this->uri->segment(4);
    $this->load->model('Authme_model');
    $user = $this->Authme_model->get_user_by_email($email);
    if ($user) {
      if ($user->acode <> 1) {
        if ($user->acode <> $acode) {
          $data['msg'] = '<span class="error">Error: Invalid activation code!</span>';
        }
        else {
          $data = array('acode' => 1, 'status' => 0);
          $this->Authme_model->update_user($user->id, $data);
          $data['msg'] = '<span class="success">Thank you, successfully activated!</span>';
        }
      }
      else {
        $data['msg'] = '<span class="success">Thank you, activated before!</span>';
      }
    }
    else {
      $data['msg'] = '<span class="error">Error: Invalid email address!</span>';
    }
    $data['title'] = $data['desc'] = 'Activate';
    $this->load->view('auth/active', $data);
  }
}