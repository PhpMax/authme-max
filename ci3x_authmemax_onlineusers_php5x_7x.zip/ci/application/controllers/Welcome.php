<?php
/*
* AuthMeMax Users Library
*
* @package Authentication
* @category Libraries
* @author Moh Shair
* @link http://php-max.com/ci
* @version 1.0
*
*/
defined('BASEPATH') OR exit ('No direct script access allowed');
class Welcome extends CI_Controller {
  public function index() {
    $data['title'] = 'Welcome';
    $data['desc'] = 'AuthmeMax demo page';
    $user = $this->session->userdata('user');
    $uid = user('id');
    if (user('id') == 1) {
      $data['admin'] = 1;
    }
    else {
      $data['admin'] = 0;
    }
    $this->load->view('welcome_message', $data);
  }
}