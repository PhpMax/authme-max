<?php
/*
* AuthMeMax Users Library
*
* @package Authentication
* @category Libraries
* @author Moh Shair
* @link http://php-max.com/ci
* @version 1.0
*
*/
if (!defined('BASEPATH'))
  exit ('No direct script access allowed');
class Users extends CI_Controller {
  function __construct() {
    parent :: __construct();
    $this->load->model('users_model');
  }
  public function index() {
    $this->load->library('pagination');
    $page = $this->uri->segment(3);
    $config['base_url'] = base_url() . 'users/index/';
    $data['total_rows'] = $config['total_rows'] = $this->users_model->get_all_posts_num();
    $this->pagination->initialize($config);
    $data['pager'] = $this->pagination->create_links();
    $data['query'] = $this->users_model->get_all_posts($page);
    $user = $this->session->userdata('user');
    if (user('id') == 1) {
      $data['admin'] = 1;
    }
    else {
      $data['admin'] = 0;
    }
    if ($page) {
      $data['title'] = $data['desc'] = "Members " . ' - Page: ' . $page;
    }
    else {
      $data['title'] = $data['desc'] = "Members";
    }
    $this->load->view('users/index', $data);
  }
  public function post() {
    $id = $this->uri->segment(2);
    if ($this->users_model->get_post($id)) {
      foreach ($this->users_model->get_post($id) as $row) {
        $data['id'] = $row->id;
        $data['username'] = $row->username;
        $data['created'] = $row->created;
        $data['last_login'] = $row->last_login;
        $data['email'] = $row->email;
        $data['ip'] = $row->ip;
        $data['status'] = $row->status;
        $data['gender'] = $row->gender;
        $data['birthdate'] = $row->birthdate;
        $data['country'] = $row->country;
        $data['website'] = $row->website;
        $data['acode'] = $row->acode;
        $data['found'] = 1;
        $data['x'] = 0;
        if (user('id') == 1) {
          $data['admin'] = 1;
        }
        else {
          $data['admin'] = 0;
        }
      }
      $data['title'] = $data['desc'] = $data['username'];
    }
    else {
      $data['found'] = 0;
      $data['title'] = $data['desc'] = "Member doesn't exists!";
    }
    $data['flashdata'] = $this->session->flashdata('flashdata');
    $this->load->view('users/post', $data);
  }
  public function edit() {
    $id = user('id');
    $flashdata = 'Updated successfully';
    $username = user('username');
    $data['title'] = $data['desc'] = "Control panel";
    $this->load->helper('form');
    $this->load->helper('email');
    if (logged_in()) {
      foreach ($this->users_model->get_post($id) as $row) {
        $id = $data['id'] = $row->id;
        $country = $data['country'] = $row->country;
        $birthdate = $row->birthdate;
        $gender = $data['gender'] = $row->gender;
        $email = $data['email'] = $row->email;
        $website = $data['website'] = $row->website;
        if ($birthdate) {
          $birthdateArr = explode('.', $birthdate);
          $data['bday'] = $birthdateArr[0];
          $data['bmonth'] = $birthdateArr[1];
          $data['byear'] = $birthdateArr[2];
        }
        else {
          $data['bday'] = 0;
          $data['bmonth'] = 0;
          $data['byear'] = 0;
        }
      }
      if (isset ($_POST['id'])) {
        $id = (int) $this->input->post('id');
        $country = trim(strip_tags($this->input->post('country')));
        $byear = (int) $this->input->post('byear');
        $bmonth = (int) $this->input->post('bmonth');
        $bday = (int) $this->input->post('bday');
        $gender = (int) $this->input->post('gender');
        $birthdate = "$bday.$bmonth.$byear";
        $website = trim(strip_tags($this->input->post('website')));
        $email = $data['email'] = trim(strip_tags($this->input->post('email')));
        $arr = array('country' => $country, 'gender' => $gender, 'birthdate' => $birthdate, 'website' => $website);
        $this->users_model->update_user($id, $arr);
        $this->session->set_flashdata('message', '1 users updated!');
        if ($this->input->post('password')) {
          $this->authme->reset_password($id, $this->input->post('password'));
          $flashdata = $flashdata . '<br />You have changed your password.';
        }
        if ($email <> user('email')) {
          if (!valid_email($email) || $this->email_exists($email)) {
            $email = user('email');
            $flashdata = $flashdata . '<br />Error: Email used.';
          }
          else {
            $acode = '';
            for ($i = 0; $i < $length; $i++) {
              $acode .= $characters[rand(0, $charactersLength - 1)];
            }
            $this->authme->change_email($id, $email, $acode);
            $flashdata = $flashdata . '<br />Email has been changed, please login again.';
          }
        }
        $this->session->set_flashdata('flashdata', $flashdata);
        redirect('users/' . $id);
      }
      else {
        $this->load->view('users/edit', $data);
      }
    }
    else {
      $this->load->view('users/edit', $data);
    }
  }
  public function email_exists($email) {
    $this->load->model('Authme_model');
    if ($this->Authme_model->get_user_by_email($email)) {
      return true;
    }
    else {
      return false;
    }
  }
}